const { BedrockRuntimeClient, InvokeModelCommand } = require("@aws-sdk/client-bedrock-runtime");

// Khởi tạo client kết nối AWS Bedrock
const client = new BedrockRuntimeClient({ region: "us-east-1" }); 

const processUserMessage = async (message) => {
  try {
    // In log xác thực gửi request thực tế qua SDK
    console.log('[AWS Bedrock SDK] Đang khởi tạo kết nối và gửi request tới model Claude 3 Haiku...');

    const payload = {
      anthropic_version: "bedrock-2023-05-31",
      max_tokens: 300,
      messages: [{ role: "user", content: message }]
    };

    const command = new InvokeModelCommand({
      modelId: "anthropic.claude-3-haiku-20240307-v1:0",
      contentType: "application/json",
      accept: "application/json",
      body: JSON.stringify(payload)
    });

    const response = await client.send(command);
    const responseData = JSON.parse(new TextDecoder().decode(response.body));

    console.log('[AWS Bedrock SDK] Nhận phản hồi thành công từ AWS Bedrock!');

    return {
      type: 'ai_response',
      text: responseData.content[0].text
    };
  } catch (error) {
    console.log('[AWS Bedrock Notice] Không tìm thấy AWS Credentials cục bộ/API bị hạn chế. Kích hoạt fallback response để duy trì độ ổn định hệ thống.');
    console.error("Chi tiết lỗi kết nối AWS Bedrock:", error.message);

    return {
      type: 'ai_response',
      text: "🤖 [AI Assistant]: Không thể kết nối tới AWS Bedrock (Thiếu AWS Credentials). Hệ thống đang chạy chế độ mô phỏng phản hồi."
    };
  }
};

module.exports = { processUserMessage };