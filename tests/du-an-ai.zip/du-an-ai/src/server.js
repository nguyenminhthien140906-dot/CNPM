const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

// Import module AI Chatbot chúng ta vừa tạo
const { processUserMessage } = require('./ai/aiChat'); // Nếu file aiChat.js nằm cùng thư mục src

const app = express();
app.use(cors());

const path = require('path');
app.use(express.static(path.join(__dirname, '../')));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] }
});

// Lắng nghe kết nối Socket.IO từ Client
io.on('connection', (socket) => {
  console.log('Người dùng đã kết nối:', socket.id);

  // Xử lý gửi/nhận tin nhắn Chat & Tích hợp AI
  socket.on('send_message', async (data) => {
    // 1. Gửi tin nhắn thông thường cho mọi người trong phòng
    io.emit('receive_message', data);

    // 2. Nếu người dùng gõ gọi AI (bắt đầu bằng từ khóa @ai)
    if (data.message && data.message.startsWith('@ai')) {
      const prompt = data.message.replace('@ai', '').trim();
      const aiReply = await processUserMessage(prompt);
      
      // Gửi phản hồi tự động từ AI trả về cho client
      io.emit('receive_message', {
        sender: 'AI Assistant',
        message: aiReply.text
      });
    }
  });

  // Xử lý tín hiệu WebRTC Signaling (Meeting / Video Call)
  socket.on('join_room', (roomId) => {
    socket.join(roomId);
    console.log(`User ${socket.id} đã vào phòng: ${roomId}`);
  });

  // Trao đổi tín hiệu WebRTC cho chức năng Meeting / Video Call
  socket.on('sending_signal', (payload) => {
    io.to(payload.userToSignal).emit('user_joined_signal', { 
      signal: payload.signal, 
      callerID: payload.callerID 
    });
  });

  socket.on('returning_signal', (payload) => {
    io.to(payload.callerID).emit('receiving_returned_signal', { 
      signal: payload.signal, 
      id: socket.id 
    });
  });

  socket.on('disconnect', () => {
    console.log('Người dùng đã ngắt kết nối:', socket.id);
  });
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server đang chạy tại cổng http://localhost:${PORT}`);
});